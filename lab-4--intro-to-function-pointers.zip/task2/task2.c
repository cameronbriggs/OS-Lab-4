#include <stdio.h>
#include <stdlib.h>

/* Original Function Declaration */
int add(int a, int b);

int main(void)
{
    int userNumber1, userNumber2;
    char userChoice;

    printf("Enter two numbers: ");
    scanf("%d %d", &userNumber1, &userNumber2);

    printf("Pick Operation'a' - add, 'b' - exit): ");
    scanf(" %c", &userChoice);

    switch (userChoice)
    {
    case 'a':
        printf("Result: %d\n", add(userNumber1, userNumber2));
        break;
    case 'b':
        exit(0);
        break;
    default:
        printf("Error! Pick another choice\n");
    }

    return 0;
}

/* Original Function Definition */
int add(int a, int b)
{
    printf("Adding 'a' and 'b'\n");
    return a + b;
}
